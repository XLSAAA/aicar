#ifndef _ANO_H
#define _ANO_H
#include "headfile.h"
void data_to_ANO(void);
#endif