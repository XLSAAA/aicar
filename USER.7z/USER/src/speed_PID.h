#ifndef __speed_PID_H__
#define __speed_PID_H__

#include "fsl_common.h"
#include "common.h"

extern float mkp,mki,mkd;
extern float out_increment;
extern float out;
extern int16 speed;
extern int16 set_speed;
extern int16 ek,ek1,ek2;
extern int32 motor_duty;

extern float mkpb,mkib,mkdb;
extern float out_incrementb;
extern float outb;
extern int16 speedb;
extern int16 set_speedb;
extern int16 ekb,ek1b,ek2b;
extern int32 motor_dutyb;


void getmotorpid(void);

#endif