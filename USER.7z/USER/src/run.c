/*#include "run.h"
#include "headfile.h"

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "board.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "nncie.h"

uint8 adsucces;	//1��ad���ݲɼ����   0��ad����δ�ɼ����
int8 ad1,ad2,ad3,ad4,ad5,ad6,ad7,ad8;//ad����
*/
/*void ad_collection(void)
{
	  ad1 = adc_mean_filter(ADC_1,ADC1_CH3_B14 ,10)-128;
    ad2 = adc_mean_filter(ADC_1,ADC1_CH7_B18 ,10)-128;
    ad3 = adc_mean_filter(ADC_1,ADC1_CH13_B24 ,10)-128;
    ad4 = adc_mean_filter(ADC_1,ADC1_CH14_B25 ,10)-128;
	
	
	
		adsucces = 1;
}


int8 cie_data[7];
void cie_data_get(void)
{
	
	cie_data[0] = ad1;
	cie_data[1] = ad2;
	cie_data[2] = ad3;
	cie_data[3] = ad4;
	
}
*/

/*#define SMOTOR_CENTER   3750//�����ֵ
#define SMOTOR_RANGE    400	//�������ֵ
int16 smotor_angle;			//������Ʊ���


void smotor_control(void)
{
	smotor_angle = (int16)limit(smotor_angle,SMOTOR_RANGE);//�޷��������������ֿ��� ���¶���ջ�
    //���������
    pwm_duty(PWM4_MODULE3_CHA_C31,SMOTOR_CENTER+smotor_angle);
}

void run(void)
{
	
	int16 temp;
	ModelInfo_t inf;
//									int16 g_out[1];
	const CI_OutMetricInfo* pOM = CI_GetOutMetricInfo(0);
//ad caiji
	
	ad_collection();
	
}
	//motor pwm
	//pwm_init(PWM4_MODULE3_CHA_C31,50,3750);
	//pwm_init(PWM1_MODULE3_CHB_D1 , 50, 50000);
  //pwm_init(PWM1_MODULE3_CHA_D0 , 50, 0);
  //pwm_init(PWM2_MODULE3_CHB_D3 , 50, 50000);
  //pwm_init(PWM2_MODULE3_CHA_D2 , 50, 0);
	*/
	/*if(adsucces)
	{
		
		adsucces = 0;
		
		cie_data_get();
		CI_RunModelXIP(model1, cie_data, &temp);
		int16_t g_servoValue;
		if(inf.quantBits>7)
			{
				//int16_t *g_out16 = (int16_t *)g_out;
				g_servoValue = temp >> (inf.quantBits - pOM->fracBits - 1);
				g_servoValue = temp>>3;
			}
			else
			{
				g_servoValue = temp;
			}
		
			smotor_angle = g_servoValue * (int32)420 / 128;//�Ŵ�����
			smotor_control();
			
	}
	
//}*/