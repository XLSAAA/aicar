#include "headfile.h"

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "board.h"
#include "isr.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "run.h"
#include "speed_PID.h"
#include "nncie.h"
 #define IMAGE_SIZE    (8 + 32*32*3)  // 3080
 
 //extern void* RunModel(const void *in_buf);
 
 //int16 g_out[1];
 
 #define SYSTICK_PRESCALE 10

uint8 send_buff[20];		//wuxian chuankou?



//float smotor_center = 3750;
#define SMOTOR_RANGE 400
//double smotor_angle;

float smotor_end;
/*
struct pid_dj
{
	double kp,ki,kd;
	double speed_now,speed_set,speed_out;
	double i,vol;
	double err,err_pre,err_pre_pre;
	double umax,umin;
}pid,pid2;

double kp_zl = 0.6;
double kd_zl = 0.01;
double ki_zl = 0.01;


//zuo
double pid_zl(double speed)
{
	pid.speed_set = speed;
	
	pid.speed_now = encoder1 / 6;
	
	pid.err = pid.speed_set - pid.speed_now;
	
	pid.vol += pid.kp * (pid.err - pid.err_pre) + pid.ki * pid.err + pid.kd * (pid.err - 2 * pid.err_pre + pid.err_pre_pre);
	pid.err_pre_pre = pid.err_pre;
	pid.err_pre = pid.err;
	
	pid.speed_out = pid.vol * 1.0;
	
	if(pid.speed_out > pid.umax) pid.speed_out = pid.umax;
	if(pid.speed_out < pid.umin) pid.speed_out = pid.umin;
}
*/




/*
uint8 example_rx_buffer;
lpuart_transfer_t   example_receivexfer;
lpuart_handle_t     example_g_lpuartHandle;


uint8 uart_data;

void example_uart_callback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData)
{
    if(kStatus_LPUART_RxIdle == status)
    {
        //�����Ѿ���д�뵽�� ֮ǰ���õ�BUFF��
        //������ʹ�õ�BUFFΪ example_rx_buffer
        uart_data = example_rx_buffer;//������ȡ��
    }
    
    handle->rxDataSize = example_receivexfer.dataSize;  //��ԭ����������
    handle->rxData = example_receivexfer.data;          //��ԭ��������ַ
}
uint8 uart_send;

*/

int main(void)
{
	//chu shi hua

	DisableGlobalIRQ();
	board_init();
	pit_init(); 
	pit_interrupt_ms(PIT_CH0,5);

	//systick_delay_ms(100);
	gpio_init(B9,GPO,1,GPIO_PIN_CONFIG);
	//�ɻɹ�
	gpio_init(C4,GPI,1,GPIO_PIN_CONFIG);
	//������
	gpio_init(B11,GPO,0,GPIO_PIN_CONFIG);
	//chuan kou
	seekfree_wireless_init();
	
/*	
	//��ʼ������   ������Ϊ115200 TXΪD16 RXΪD17
    uart_init (USART_8, 115200,UART8_TX_D16,UART8_RX_D17);	
    NVIC_SetPriority(LPUART8_IRQn,15);         //���ô����ж����ȼ� ��Χ0-15 ԽС���ȼ�Խ��
    uart_rx_irq(USART_8,1);
    
    //���ô��ڽ��յĻ�����������������
    example_receivexfer.dataSize = 1;
    example_receivexfer.data = &example_rx_buffer;
    
    //�����жϺ����������
    uart_set_handle(USART_8, &example_g_lpuartHandle, example_uart_callback, NULL, 0, example_receivexfer.data, 1);
		
		*/
		
	/*adc_init(ADC_1,ADC1_CH15_B26,ADC_10BIT);
	adc_init(ADC_1,ADC1_CH9_B20,ADC_10BIT);
  adc_init(ADC_1,ADC1_CH7_B18,ADC_10BIT);
	adc_init(ADC_1,ADC1_CH10_B21,ADC_10BIT);
	adc_init(ADC_1,ADC1_CH6_B17,ADC_10BIT);
	adc_init(ADC_1,ADC1_CH8_B19,ADC_10BIT);
	// 0.48  14500   0.5 16500  0.55 18500  0.485 16500
	adc_init(ADC_1,ADC1_CH13_B24,ADC_10BIT);
	*/
	//adc_init(ADC_1,ADC1_CH14_B25,ADC_8BIT);
	adc_init(ADC_1,ADC1_CH13_B24,ADC_10BIT);
	adc_init(ADC_2,ADC2_CH1_B28,ADC_10BIT);
	pwm_init(PWM4_MODULE3_CHA_C31,50,3750);
	pwm_init(PWM1_MODULE3_CHB_D1 , 15000, 0); //13500  
  pwm_init(PWM1_MODULE3_CHA_D0 , 15000, 0);
  pwm_init(PWM2_MODULE3_CHB_D3 , 15000, 0); //13500
  pwm_init(PWM2_MODULE3_CHA_D2 , 15000, 0);
	//һ��QTIMER���� ����������������
    //��ʼ�� QTIMER_1 A��ʹ��QTIMER1_TIMER0_C0 B��ʹ��QTIMER1_TIMER1_C1
    qtimer_quad_init(QTIMER_1,QTIMER1_TIMER0_C0,QTIMER1_TIMER1_C1);
    
    //��ʼ�� QTIMER_1 A��ʹ��QTIMER1_TIMER2_C2 B��ʹ��QTIMER1_TIMER3_C24
    qtimer_quad_init(QTIMER_1,QTIMER1_TIMER2_C2,QTIMER1_TIMER3_C24);

    
    qtimer_quad_init(QTIMER_2,QTIMER2_TIMER0_C3,QTIMER2_TIMER3_C25);
    qtimer_quad_init(QTIMER_3,QTIMER3_TIMER2_B18,QTIMER3_TIMER3_B19);
	EnableGlobalIRQ(0);
	
	/*SysTick_Config(CLOCK_GetFreq(kCLOCK_CoreSysClk) / (SYSTICK_PRESCALE * 10000U));
	
	const CI_OutMetricInfo* pOM = CI_GetOutMetricInfo(0);
	*/
	//CI_GetModelInfoXIP(model1, &inf);
	/*pid.err = 0.0;
	pid.err_pre = 0.0;
	pid.err_pre_pre = 0.0;
	pid.i = 0.0;
	pid.kp = kp_zl;
	pid.ki = ki_zl;
	pid.kd = kd_zl;
	pid.speed_now = 0.0;
	pid.speed_set = 0.0;
	pid.speed_out = 0.0;
	pid.vol = 0.0;
	pid.umax = 200;
	pid.umin = 0;
	*/
	while(1)
	{
		
		if(flag > 2000) flag = 2000;
		if(gpio_get(C4)==0 && flag > 1000) //��⵽
		{
			
			gpio_set(B11,1);
			/*set_speedb = 0;
			set_speed = 0;
			mki = 20;
			mkib = 20;
			*/
			
			
			
			pwm_duty(PWM1_MODULE3_CHB_D1,0);
			pwm_duty(PWM1_MODULE3_CHA_D0,50000);
			pwm_duty(PWM2_MODULE3_CHB_D3,50000);
			pwm_duty(PWM2_MODULE3_CHA_D2,0);
			systick_delay_ms(300);
			while(1)
			{
			pwm_duty(PWM1_MODULE3_CHB_D1,0);
			pwm_duty(PWM1_MODULE3_CHA_D0,0);
			pwm_duty(PWM2_MODULE3_CHB_D3,0);
			pwm_duty(PWM2_MODULE3_CHA_D2,0);
			}
			
			
			
		}
		else if(gpio_get(C4) == 1)
		{
			gpio_set(B11,0);
		}
		
		 //  data_to_ANO();
			
		 //error_pre = error;
		
		  if(ad5 < 160 && ad2 < 50)
			{
				pwm_duty(PWM1_MODULE3_CHB_D1,0);
				pwm_duty(PWM1_MODULE3_CHA_D0,0);
				pwm_duty(PWM2_MODULE3_CHB_D3,0);
				pwm_duty(PWM2_MODULE3_CHA_D2,0);
				
				//pid_add_duty(encoder1 / 6);
				
			}
		
			else
			{
		
		  
		
		/*if(smotor_angle - 3750 > 0) //zuo
		{
			a = (int16)(40*(smotor_angle - 3750) * 2 / 380);
			if(a > 40) a = 40;
			if(a < 40) a = 0;
			motor_dutyb = motor_dutyb - (motor_dutyb / 40) * a * 1;
		}
		else
		{
			a = (int16)(40*-(smotor_angle - 3750) * 2 / 380);
			if(a > 40) a = 40;
			if(a < 40) a = 0;
			motor_duty = motor_duty - (motor_duty / 40) * a * 1;
		}
			*/
		if(motor_dutyb > 0)
		{
			pwm_duty(PWM1_MODULE3_CHB_D1,motor_dutyb);
				pwm_duty(PWM1_MODULE3_CHA_D0,0);
		}
		else
		{
			pwm_duty(PWM1_MODULE3_CHB_D1,0);
			pwm_duty(PWM1_MODULE3_CHA_D0,-motor_dutyb);
		}
		
		if(motor_duty > 0)
		{
			pwm_duty(PWM2_MODULE3_CHB_D3,0);
			pwm_duty(PWM2_MODULE3_CHA_D2,motor_duty);
		}
		else
		{
			pwm_duty(PWM2_MODULE3_CHB_D3,-motor_duty);
			pwm_duty(PWM2_MODULE3_CHA_D2,0);
		}
		
	}
	
				
			
				
	
	/*	if(collection_success)
		 {
			 
			 collection_success = 0;
			 send_buff[0] = 0;
			 send_buff[1] = 0;
			 send_buff[2] = ad1;
			 send_buff[3] = ad3;
			 send_buff[4] = ad4;
			 send_buff[5] = ad5;
			 send_buff[6] = ad2;
			 send_buff[7] = ad6;
			 send_buff[8] = ad7;
			 send_buff[9] = (int32)(smotor_angle - smotor_center)*128/400;
			 
			 send_buff[10] = 0x5a;
			 
			 seekfree_wireless_send_buff(send_buff,11);
			 
		 }*/
		 
}
	
}