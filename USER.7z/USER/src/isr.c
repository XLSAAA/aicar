/*********************************************************************************************************************
 * COPYRIGHT NOTICE
 * Copyright (c) 2019,��ɿƼ�
 * All rights reserved.
 * ��������QQȺ��һȺ��179029047(����)  ��Ⱥ��244861897
 *
 * �����������ݰ�Ȩ������ɿƼ����У�δ����������������ҵ��;��
 * ��ӭ��λʹ�ò������������޸�����ʱ���뱣����ɿƼ��İ�Ȩ������
 *
 * @file       		isr
 * @company	   		�ɶ���ɿƼ����޹�˾
 * @author     		��ɿƼ�(QQ3184284598)
 * @version    		�鿴doc��version�ļ� �汾˵��
 * @Software 		IAR 8.3 or MDK 5.28
 * @Target core		NXP RT1064DVL6A
 * @Taobao   		https://seekfree.taobao.com/
 * @date       		2019-04-30
 ********************************************************************************************************************/

#include "headfile.h"
#include "isr.h"
#include "speed_PID.h"
float ad1,ad2,ad3,ad4,ad5,ad6,ad7;
float error =0;
float set_out = 0;
float actual_in = 0;
float err =0 ;
float invole = 0;
float actual_out = 0;
float kp = 0.514;//  0.504
float ki = 0.0;
float errrr;
float kd =8.02; //8.02

int16 encoder1;
int16 encoder2;
int16 encoder3;
int16 encoder4;

// p 0.487 d 0.25  17500   0.5 0.277  18500
float err_last = 0;
int collection_success = 0;
void CSI_IRQHandler(void)
{
    CSI_DriverIRQHandler();     //����SDK�Դ����жϺ��� ���������������������õĻص�����
    __DSB();                    //����ͬ������
}

int ad[100];
int temp[100];


void merge_sort(int ad[],int l,int r)
{
	if(l >= r) return;
	int mid = (l + r) >> 1;
	merge_sort(ad,l,mid),merge_sort(ad,mid + 1 , r);
	int i = l, j = mid + 1, k = 0;
	while(i <= mid && j <= r)
	{
		if(ad[i] <= ad[j]) temp[k++] = ad[i++];
		else temp[k++] = ad[j++];
	}
	while(i <= mid) temp[k++] = ad[i++];
	while(j <= r) temp[k++] = ad[j++];
	
	for(i = l, j = 0 ; i <= r ; i ++, j++) ad[i] = temp[j];
}

int lvbo(int adc_1,int kou)
{
	int flag = 0;
	for(int i = 0 ;  i < 10 ; i++) ad[i] = adc_convert(adc_1,kou);
	merge_sort(ad,0,9);
	for(int i = 3 ; i < 8 ; i ++)
	{
		flag += ad[i];
	}
	flag = flag / 5;
	
	return flag;
}

void ad_collection(void)
{
	
	/*
	//ad1 = adc_mean_filter(ADC_1,ADC1_CH11_B22 ,10) /100;
	ad1 = adc_convert(ADC_1,ADC1_CH15_B26);
	//ad2 = adc_mean_filter(ADC_1,ADC1_CH7_B18 ,10) /100;
	ad2 = adc_convert(ADC_1,ADC1_CH7_B18);
	ad3 = adc_convert(ADC_1,ADC1_CH10_B21);
	ad4 = adc_convert(ADC_1,ADC1_CH9_B20);
	ad5 = adc_convert(ADC_1,ADC1_CH8_B19); 
	ad6 = adc_convert(ADC_1,ADC1_CH13_B24);
	ad7 = adc_convert(ADC_1,ADC1_CH6_B17);
	//ad3 = adc_mean_filter(ADC_1,ADC1_CH5_B16 ,10) /100;
	//ad4 = adc_mean_filter(ADC_1,ADC1_CH4_B15 ,10) /100; 
	//ad5 = adc_mean_filter(ADC_1,ADC1_CH6_B17 ,10) /100;
  //ad6 = adc_mean_filter(ADC_1,ADC1_CH15_B26 ,10) /100;
	*/
	//ad1 = lvbo(ADC_1,ADC1_CH15_B26);
	ad2 = lvbo(ADC_1,ADC1_CH13_B24);
	//ad3 = lvbo(ADC_1,ADC1_CH10_B21);
	//ad4 = lvbo(ADC_1,ADC1_CH9_B20);
	ad5 = lvbo(ADC_2,ADC2_CH1_B28)+20;
	//ad6 = lvbo(ADC_1,ADC1_CH13_B24);
	//ad7 = lvbo(ADC_1,ADC1_CH6_B17);
	//ad2 = adc_convert(ADC_1,ADC1_CH13_B24);
	//ad2 = lvbo(ADC_1,ADC1_CH13_B24);
	
	//ad5 = adc_convert(ADC_2,ADC2_CH1_B28);
	collection_success = 1;
}



float PID_place_duty(float steer)
{
	set_out=0.0;
	actual_in=steer;
	err=set_out-actual_in;
	invole+=err;

	actual_out=kp*err+ki*invole+kd*(err-err_last);
	err_last=err;	
	return actual_out;
}
float smotor_center = 3750;
double smotor_angle;
void smotor_control(void)
{
	//smotor_angle = (int16)limit(smotor_angle,SMOTOR_RANGE);
	if(smotor_angle >= 4130 )
	{
		pwm_duty(PWM4_MODULE3_CHA_C31,4130); 
	}
		
	else if(smotor_angle <= 3370)
	{
		pwm_duty(PWM4_MODULE3_CHA_C31,3370);
	}
	
	else	pwm_duty(PWM4_MODULE3_CHA_C31,smotor_angle); 
	//pwm_init(PWM4_MODULE3_CHA_C31,50,smotor_angle);
	
}
int16 a;
int flag = 0;
void PIT_IRQHandler(void)
{
	
    if(PIT_FLAG_GET(PIT_CH0))
    {
        PIT_FLAG_CLEAR(PIT_CH0);
        
    }
		flag++;
    ad_collection();
		if(ad5 + ad2 == 0)
		{
			error = 0;
		}
		else
		 error = (ad2 - ad5)/(ad5 + ad2);
		
		 //PID_init();
		 error = PID_place_duty(error);
		
		//bian ma qi
	
		encoder1 = qtimer_quad_get(QTIMER_1,QTIMER1_TIMER0_C0 );
    encoder2 = -qtimer_quad_get(QTIMER_1,QTIMER1_TIMER2_C2 );
        //encoder3 = qtimer_quad_get(QTIMER_2,QTIMER2_TIMER0_C3 );
        //encoder4 = qtimer_quad_get(QTIMER_3,QTIMER3_TIMER2_B18);
		qtimer_quad_clear(QTIMER_1,QTIMER1_TIMER0_C0 );
    qtimer_quad_clear(QTIMER_1,QTIMER1_TIMER2_C2 );
		getmotorpid();
		smotor_angle = (smotor_center / 1000.0 + error)*1000;
        //qtimer_quad_clear(QTIMER_2,QTIMER2_TIMER0_C3 );
        //qtimer_quad_clear(QTIMER_3,QTIMER3_TIMER2_B18);
		smotor_control();
		if(smotor_angle - 3750 > 0) //zuo
		{
			a = (int16)(40*(smotor_angle - 3750) * 1.5 / 380); //1.5
			if(a > 40) a = 40;
			if(a < 40) a = 0;
			motor_dutyb = motor_dutyb - (motor_dutyb / 70) * a * 1;
		}
		else
		{
			a = (int16)(40*-(smotor_angle - 3750) * 1.5 / 380);
			if(a > 40) a = 40;
			if(a < 40) a = 0;
			motor_duty = motor_duty - (motor_duty / 70) * a * 1;
		}
		
		
    if(PIT_FLAG_GET(PIT_CH1))
    {
        PIT_FLAG_CLEAR(PIT_CH1);
    }
    
    if(PIT_FLAG_GET(PIT_CH2))
    {
        PIT_FLAG_CLEAR(PIT_CH2);
    }
    
    if(PIT_FLAG_GET(PIT_CH3))
    {
        PIT_FLAG_CLEAR(PIT_CH3);
    }

    __DSB();
		
}


void GPIO2_Combined_16_31_IRQHandler(void)
{
    if(GET_GPIO_FLAG(C16))
    {
        CLEAR_GPIO_FLAG(C16);//����жϱ�־λ
    }
    
    
}



void GPIO2_Combined_0_15_IRQHandler(void)
{
    if(GET_GPIO_FLAG(MT9V03X_VSYNC_PIN))
    {
        //���������־λ����־λ��mt9v03x_vsync�����ڲ������
        if(1 == flexio_camera_type)mt9v03x_vsync();
    }
    if(GET_GPIO_FLAG(SCC8660_VSYNC_PIN))
    {
        //���������־λ����־λ��scc8660_vsync�����ڲ������
        if(2 == flexio_camera_type)scc8660_vsync();
    }
}



/*
�жϺ������ƣ��������ö�Ӧ���ܵ��жϺ���
Sample usage:��ǰ���������ڶ�ʱ���ж�
void PIT_IRQHandler(void)
{
    //��������־λ
    __DSB();
}
�ǵý����жϺ������־λ
CTI0_ERROR_IRQHandler
CTI1_ERROR_IRQHandler
CORE_IRQHandler
FLEXRAM_IRQHandler
KPP_IRQHandler
TSC_DIG_IRQHandler
GPR_IRQ_IRQHandler
LCDIF_IRQHandler
CSI_IRQHandler
PXP_IRQHandler
WDOG2_IRQHandler
SNVS_HP_WRAPPER_IRQHandler
SNVS_HP_WRAPPER_TZ_IRQHandler
SNVS_LP_WRAPPER_IRQHandler
CSU_IRQHandler
DCP_IRQHandler
DCP_VMI_IRQHandler
Reserved68_IRQHandler
TRNG_IRQHandler
SJC_IRQHandler
BEE_IRQHandler
PMU_EVENT_IRQHandler
Reserved78_IRQHandler
TEMP_LOW_HIGH_IRQHandler
TEMP_PANIC_IRQHandler
USB_PHY1_IRQHandler
USB_PHY2_IRQHandler
ADC1_IRQHandler
ADC2_IRQHandler
DCDC_IRQHandler
Reserved86_IRQHandler
Reserved87_IRQHandler
GPIO1_INT0_IRQHandler
GPIO1_INT1_IRQHandler
GPIO1_INT2_IRQHandler
GPIO1_INT3_IRQHandler
GPIO1_INT4_IRQHandler
GPIO1_INT5_IRQHandler
GPIO1_INT6_IRQHandler
GPIO1_INT7_IRQHandler
GPIO1_Combined_0_15_IRQHandler
GPIO1_Combined_16_31_IRQHandler
GPIO2_Combined_0_15_IRQHandler
GPIO2_Combined_16_31_IRQHandler
GPIO3_Combined_0_15_IRQHandler
GPIO3_Combined_16_31_IRQHandler
GPIO4_Combined_0_15_IRQHandler
GPIO4_Combined_16_31_IRQHandler
GPIO5_Combined_0_15_IRQHandler
GPIO5_Combined_16_31_IRQHandler
WDOG1_IRQHandler
RTWDOG_IRQHandler
EWM_IRQHandler
CCM_1_IRQHandler
CCM_2_IRQHandler
GPC_IRQHandler
SRC_IRQHandler
Reserved115_IRQHandler
GPT1_IRQHandler
GPT2_IRQHandler
PWM1_0_IRQHandler
PWM1_1_IRQHandler
PWM1_2_IRQHandler
PWM1_3_IRQHandler
PWM1_FAULT_IRQHandler
SEMC_IRQHandler
USB_OTG2_IRQHandler
USB_OTG1_IRQHandler
XBAR1_IRQ_0_1_IRQHandler
XBAR1_IRQ_2_3_IRQHandler
ADC_ETC_IRQ0_IRQHandler
ADC_ETC_IRQ1_IRQHandler
ADC_ETC_IRQ2_IRQHandler
ADC_ETC_ERROR_IRQ_IRQHandler
PIT_IRQHandler
ACMP1_IRQHandler
ACMP2_IRQHandler
ACMP3_IRQHandler
ACMP4_IRQHandler
Reserved143_IRQHandler
Reserved144_IRQHandler
ENC1_IRQHandler
ENC2_IRQHandler
ENC3_IRQHandler
ENC4_IRQHandler
TMR1_IRQHandler
TMR2_IRQHandler
TMR3_IRQHandler
TMR4_IRQHandler
PWM2_0_IRQHandler
PWM2_1_IRQHandler
PWM2_2_IRQHandler
PWM2_3_IRQHandler
PWM2_FAULT_IRQHandler
PWM3_0_IRQHandler
PWM3_1_IRQHandler
PWM3_2_IRQHandler
PWM3_3_IRQHandler
PWM3_FAULT_IRQHandler
PWM4_0_IRQHandler
PWM4_1_IRQHandler
PWM4_2_IRQHandler
PWM4_3_IRQHandler
PWM4_FAULT_IRQHandler
Reserved171_IRQHandler
GPIO6_7_8_9_IRQHandler*/



