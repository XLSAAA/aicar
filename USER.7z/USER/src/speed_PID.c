#include "common.h"
#include "isr.h"


float mkp,mki,mkd = 0;
float out_increment = 0;
float out = 0;
int16 speed = 0;
int16 set_speed = 75;//45
int16 ek,ek1,ek2 = 0;
int32 motor_duty = 0;

float mkpb,mkib,mkdb = 0;
float out_incrementb = 0;
float outb = 0;
int16 speedb = 0;
int16 set_speedb = 75;
int16 ekb,ek1b,ek2b = 0;
int32 motor_dutyb = 0;



void getmotorpid(void)
{
	speed = encoder1;
	speedb = encoder2;
	
	ek2 = ek1;
	ek2b = ek1b;
	
	ek1 = ek;
	ek1b = ekb;
	
	ek = set_speed - speed;
	ekb = set_speedb - speedb;
	
	
	mkp = 30;//30
	mki = 2.5;//2
	mkd = 50; //8
	
	mkpb = 30;
	mkib = 2.5;
	mkdb = 50;
	
	
	out_increment = (int16)(mkp*(ek-ek1) + mki*ek + mkd*(ek - 2*ek2 + ek2));
	out_incrementb = (int16)(mkpb*(ekb-ek1b)+mkib*ekb+mkdb*(ekb -2*ek2b+ek2b));
	
	out += out_increment;
	outb += out_incrementb;
	
	
	if(out > 50000) out = 50000;
	if(outb > 50000) outb = 50000;
	
	motor_duty = (int32)out;
	motor_dutyb = (int32)outb;
	
}